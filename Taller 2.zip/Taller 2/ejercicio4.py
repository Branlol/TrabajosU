#5. Construir un programa que reciba las componentes en x y y de un vector y calcule una proyección del 
#mismo sobre un par de vectores unitarios al azar.  El programa de permitir recibir más de un vector, pero uno 
#a la vez. Para cada caso graficar el punto inicial y los puntos que representan las proyecciones.